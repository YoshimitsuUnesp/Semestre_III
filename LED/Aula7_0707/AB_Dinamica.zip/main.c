#include <stdlib.h>
#include <stdio.h>
#include "arvoreB.h"

int main (){


	
	return 0;
}
